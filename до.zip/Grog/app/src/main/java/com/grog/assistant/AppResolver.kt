package com.grog.assistant

import android.content.Context
import android.content.Intent

/** Ищет среди установленных приложений то, которое пользователь назвал голосом. */
object AppResolver {

    class Found(val label: String, val pkg: String)

    /** Как обычно произносят по-русски приложения с английскими названиями. */
    private val ALIASES = mapOf(
        "инстаграм" to "instagram", "инста" to "instagram",
        "тикток" to "tiktok", "тик ток" to "tiktok",
        "гугл" to "google", "хром" to "chrome", "гугл хром" to "chrome",
        "почта" to "gmail", "джимейл" to "gmail", "гмайл" to "gmail",
        "карты" to "maps", "гугл карты" to "maps",
        "плей маркет" to "play store", "плэй маркет" to "play store", "гугл плей" to "play store",
        "фейсбук" to "facebook", "твиттер" to "x", "вконтакте" to "vk", "вк" to "vk",
        "вайбер" to "viber", "скайп" to "skype", "зум" to "zoom", "дискорд" to "discord",
        "спотифай" to "spotify", "нетфликс" to "netflix", "сноп" to "snapchat", "снапчат" to "snapchat",
        "яндекс" to "яндекс", "ютуб" to "youtube", "телеграм" to "telegram", "ватсап" to "whatsapp",
        "камера" to "camera", "галерея" to "gallery", "фото" to "photos",
        "калькулятор" to "calculator", "часы" to "clock", "будильник" to "clock",
        "настройки" to "settings", "контакты" to "contacts", "телефон" to "phone", "звонилка" to "phone",
        "сообщения" to "messages", "смс" to "messages", "заметки" to "notes", "календарь" to "calendar"
    )

    fun find(ctx: Context, spoken: String): Found? {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
            .map { Found(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != ctx.packageName }
        if (apps.isEmpty()) return null

        val wanted = listOf(Commands.normalize(spoken), ALIASES[Commands.normalize(spoken)])
            .filterNotNull().map { Commands.normalize(it) }.distinct()

        var best: Found? = null
        var bestScore = 0
        for (a in apps) {
            val label = Commands.normalize(a.label)
            if (label.isEmpty()) continue
            for (w in wanted) {
                val sc = when {
                    label == w -> 100
                    label.startsWith(w) && w.length >= 3 -> 80 - (label.length - w.length).coerceAtMost(20)
                    label.contains(w) && w.length >= 3 -> 60 - (label.length - w.length).coerceAtMost(20)
                    w.contains(label) && label.length >= 4 -> 50
                    w.length >= 4 && label.length >= 4 && distance(w, label) <= 2 -> 40
                    else -> 0
                }
                if (sc > bestScore) { bestScore = sc; best = a }
            }
        }
        return best
    }

    fun launch(ctx: Context, app: Found): Boolean {
        val intent = ctx.packageManager.getLaunchIntentForPackage(app.pkg) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { ctx.startActivity(intent); true } catch (e: Exception) { false }
    }

    private fun distance(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1); cur[0] = i
            for (j in 1..b.length) {
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            }
            prev = cur
        }
        return prev[b.length]
    }
}
