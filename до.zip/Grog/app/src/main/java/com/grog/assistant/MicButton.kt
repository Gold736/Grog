package com.grog.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/** Маленькая кнопка микрофона рядом с Грогом: нажми — микрофон выключится/включится. */
class MicButton(context: Context) : View(context) {

    var micOn = true
        set(v) { field = v; invalidate() }

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        bg.color = if (micOn) 0xCC2E7D32.toInt() else 0xCCC62828.toInt()
        c.drawCircle(w / 2, h / 2, w / 2, bg)

        fg.strokeWidth = w * 0.07f
        // капсула микрофона
        c.drawRoundRect(RectF(w * 0.40f, h * 0.20f, w * 0.60f, h * 0.55f), w * 0.1f, w * 0.1f, fill)
        // дуга-подставка
        c.drawArc(RectF(w * 0.30f, h * 0.32f, w * 0.70f, h * 0.68f), 0f, 180f, false, fg)
        c.drawLine(w * 0.5f, h * 0.68f, w * 0.5f, h * 0.78f, fg)
        c.drawLine(w * 0.40f, h * 0.78f, w * 0.60f, h * 0.78f, fg)
        // перечёркнут, если выключен
        if (!micOn) {
            fg.strokeWidth = w * 0.09f
            c.drawLine(w * 0.22f, h * 0.22f, w * 0.78f, h * 0.80f, fg)
        }
    }
}
