package com.grog.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private val dp: Float get() = resources.displayMetrics.density
    private fun px(v: Int) = (v * dp).toInt()
    private val prefs by lazy { getSharedPreferences("grog", MODE_PRIVATE) }

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val BG = Color.parseColor("#0D1117")
    private val CARD = Color.parseColor("#161B22")
    private val GREY = Color.parseColor("#21262D")
    private val GREEN = Color.parseColor("#238636")
    private val RED = Color.parseColor("#DA3633")
    private val MUTED = Color.parseColor("#8B949E")
    private val TEXT = Color.parseColor("#C9D1D9")

    private lateinit var micStatus: TextView
    private lateinit var overlayStatus: TextView
    private lateinit var micBtn: Button
    private lateinit var overlayBtn: Button
    private lateinit var mainBtn: Button
    private lateinit var voiceBtn: Button
    private var tts: TextToSpeech? = null
    private var ruVoices: List<Voice> = emptyList()

    private fun bg(color: Int, radius: Int = 16) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = px(radius).toFloat()
    }

    private fun txt(s: String, size: Float = 15f, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun btn(label: String, color: Int, click: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 15f
        setTextColor(Color.WHITE)
        background = bg(color, 12)
        layoutParams = LinearLayout.LayoutParams(MATCH, px(52)).apply { topMargin = px(8) }
        setOnClickListener { click() }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = bg(CARD)
        setPadding(px(16), px(14), px(16), px(14))
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = px(12) }
    }

    private fun slider(
        parent: LinearLayout, title: String, min: Float, max: Float,
        key: String, def: Float, fmt: (Float) -> String
    ) {
        val cur = prefs.getFloat(key, def)
        val head = txt("$title: ${fmt(cur)}", 14f, TEXT)
        head.setPadding(0, px(8), 0, 0)
        val bar = SeekBar(this)
        bar.max = 100
        bar.progress = (((cur - min) / (max - min)) * 100f).toInt()
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                head.text = "$title: ${fmt(min + (max - min) * p / 100f)}"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                val v = min + (max - min) * (sb?.progress ?: 0) / 100f
                prefs.edit().putFloat(key, v).apply()
                restartIfRunning()
            }
        })
        parent.addView(head)
        parent.addView(bar)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(24), px(16), px(24))
        }

        // Заголовок
        root.addView(txt("Грог", 34f, Color.WHITE, true))
        root.addView(txt("Голосовой помощник", 15f, MUTED).apply { setPadding(0, 0, 0, px(16)) })

        // Разрешения
        val perms = card()
        perms.addView(txt("Разрешения", 17f, Color.WHITE, true))
        micStatus = txt("", 15f).apply { setPadding(0, px(8), 0, 0) }
        micBtn = btn("Разрешить микрофон", GREY) { askAudio() }
        overlayStatus = txt("", 15f).apply { setPadding(0, px(8), 0, 0) }
        overlayBtn = btn("Разрешить поверх экранов", GREY) { askOverlay() }
        perms.addView(micStatus)
        perms.addView(micBtn)
        perms.addView(overlayStatus)
        perms.addView(overlayBtn)
        root.addView(perms)

        // Главная кнопка
        mainBtn = btn("Запустить Грога", GREEN) { toggleGrog() }
        (mainBtn.layoutParams as LinearLayout.LayoutParams).bottomMargin = px(16)
        root.addView(mainBtn)

        // Голос
        val voice = card()
        voice.addView(txt("Голос", 17f, Color.WHITE, true))
        slider(voice, "Высота", 0.5f, 2.0f, "pitch", 1.0f) { String.format("%.2f", it) }
        slider(voice, "Скорость речи", 0.5f, 2.0f, "rate", 1.0f) { String.format("%.2f", it) }
        voiceBtn = btn("Голос: авто (лучший)", GREY) { cycleVoice() }
        voice.addView(voiceBtn)
        voice.addView(btn("Проверить голос", GREY) { testVoice() })
        root.addView(voice)

        // Внешний вид и движение
        val look = card()
        look.addView(txt("Внешний вид и движение", 17f, Color.WHITE, true))
        slider(look, "Размер", 90f, 200f, "size", 130f) { "${it.toInt()} dp" }
        look.addView(Switch(this).apply {
            text = "Ходить по экрану"
            textSize = 15f
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("walk", true)
            setPadding(0, px(12), 0, 0)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("walk", checked).apply()
                restartIfRunning()
            }
        })
        slider(look, "Скорость ходьбы", 1f, 5f, "speed", 2.2f) { String.format("%.1f", it) }
        slider(look, "Высота над низом экрана", 0f, 120f, "floor", 8f) { "${it.toInt()} dp" }
        val jumps = Switch(this).apply {
            text = "Прыжки"
            textSize = 15f
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("jumps", true)
            setPadding(0, px(12), 0, 0)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("jumps", checked).apply()
                restartIfRunning()
            }
        }
        look.addView(jumps)
        root.addView(look)

        // Команды
        val cmds = card()
        cmds.addView(txt("Команды", 17f, Color.WHITE, true))
        cmds.addView(
            txt(
                "Скажи «Привет, Грог», потом:\n" +
                    "• «Зайди в Телеграм»\n" +
                    "• «Открой Ютуб»\n" +
                    "• «Найди котиков в ютубе»\n" +
                    "• «Открой Ватсап»\n" +
                    "• Любой вопрос: «Кто такой Пушкин?»\n" +
                    "• «Стоп» — замолчать",
                14f, TEXT
            ).apply { setPadding(0, px(8), 0, 0) }
        )
        root.addView(cmds)

        // Доступ
        val access = card()
        access.addView(txt("Разрешённые приложения", 17f, Color.WHITE, true))
        access.addView(
            txt("Telegram · YouTube · WhatsApp\nДругие приложения Грог открывать не будет.", 14f, TEXT)
                .apply { setPadding(0, px(8), 0, 0) }
        )
        root.addView(access)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(root)
        })
        initTts()
    }

    private fun initTts() {
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                try {
                    ruVoices = (tts?.voices ?: emptySet<Voice>())
                        .filter { it.locale.language == "ru" }
                        .sortedByDescending { it.quality }
                } catch (e: Exception) {
                }
                runOnUiThread { refreshVoiceBtn() }
            }
        }
    }

    private fun chosenVoice(): Voice? {
        val name = prefs.getString("voice", "") ?: ""
        return ruVoices.firstOrNull { it.name == name } ?: ruVoices.firstOrNull()
    }

    private fun refreshVoiceBtn() {
        val name = prefs.getString("voice", "") ?: ""
        val idx = ruVoices.indexOfFirst { it.name == name }
        voiceBtn.text = when {
            ruVoices.isEmpty() -> "Голос: русские голоса не найдены"
            idx < 0 -> "Голос: авто (лучший)"
            else -> "Голос ${idx + 1} из ${ruVoices.size}"
        }
    }

    private fun cycleVoice() {
        if (ruVoices.isEmpty()) return
        val name = prefs.getString("voice", "") ?: ""
        val next = ruVoices.indexOfFirst { it.name == name } + 1
        val newName = if (next >= ruVoices.size) "" else ruVoices[next].name
        prefs.edit().putString("voice", newName).apply()
        refreshVoiceBtn()
        restartIfRunning()
        testVoice()
    }

    private fun testVoice() {
        val t = tts ?: return
        chosenVoice()?.let { t.setVoice(it) }
        t.setPitch(prefs.getFloat("pitch", 1.0f))
        t.setSpeechRate(prefs.getFloat("rate", 1.0f))
        t.speak("Привет! Я Грог.", TextToSpeech.QUEUE_FLUSH, null, "test")
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun hasMic() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun updateStatus() {
        val mic = hasMic()
        val overlay = Settings.canDrawOverlays(this)
        micStatus.text = if (mic) "✓ Микрофон разрешён" else "✗ Микрофон не разрешён"
        micStatus.setTextColor(if (mic) Color.parseColor("#3FB950") else Color.parseColor("#F85149"))
        micBtn.visibility = if (mic) android.view.View.GONE else android.view.View.VISIBLE
        overlayStatus.text = if (overlay) "✓ Поверх экранов разрешено" else "✗ Поверх экранов не разрешено"
        overlayStatus.setTextColor(if (overlay) Color.parseColor("#3FB950") else Color.parseColor("#F85149"))
        overlayBtn.visibility = if (overlay) android.view.View.GONE else android.view.View.VISIBLE

        if (GrogService.isRunning) {
            mainBtn.text = "Остановить Грога"
            mainBtn.background = bg(RED, 12)
        } else {
            mainBtn.text = "Запустить Грога"
            mainBtn.background = bg(GREEN, 12)
        }
    }

    private fun askAudio() {
        val perms = if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        } else {
            arrayOf(Manifest.permission.RECORD_AUDIO)
        }
        requestPermissions(perms, 1)
    }

    private fun askOverlay() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun toggleGrog() {
        if (GrogService.isRunning) {
            stopService(Intent(this, GrogService::class.java))
            Handler(Looper.getMainLooper()).postDelayed({ updateStatus() }, 500)
            return
        }
        updateStatus()
        if (!hasMic() || !Settings.canDrawOverlays(this)) return
        startForegroundService(Intent(this, GrogService::class.java))
        Handler(Looper.getMainLooper()).postDelayed({ updateStatus() }, 500)
        moveTaskToBack(true)
    }

    private fun restartIfRunning() {
        if (!GrogService.isRunning) return
        stopService(Intent(this, GrogService::class.java))
        startForegroundService(Intent(this, GrogService::class.java))
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        updateStatus()
    }
}
